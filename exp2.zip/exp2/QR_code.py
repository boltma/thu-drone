# -*- coding: utf-8 -*-  
import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar

img=cv2.imread("imgs/1.jpg") 
print(str(img.shape[0])+"*"+str(img.shape[1]))

img=cv2.GaussianBlur(img,(5,5),0) 
kernel = cv2.getStructuringElement(cv2.MORPH_RECT,(3,3))
img = cv2.erode(img,kernel) 
_,img = cv2.threshold(img, 127, 255, 0)

texts = pyzbar.decode(img)
print(texts)

cv2.imshow("124",img)
cv2.waitKey()
